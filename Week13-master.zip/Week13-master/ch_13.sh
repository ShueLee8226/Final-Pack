#!/bin/bash

clear
echo "welcome to chapter 13"
echo "chapter 13 willl main be about the path your in"
echo "let start of check the path your in"
sleep 4
pwd
echo "in user environment"
echo "characters that need be avoid are"
echo "{ } = & < >"
sleep 1
echo "there are different bash shell"
sleep 1
echo "example are .bashrc , .cshrc "

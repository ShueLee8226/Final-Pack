# Week6
To build a bootable USB you need two item.
1. First, you'll need a USB that is 3GB or more.
2. Second, you need a program that will allow you to put an image to your USB and boot it off from it.

The program I used will be similar to everyone else.
The program is Universal USB installer.
The website is"  https://www.pendrivelinux.com/universal-usb-installer-easy-as-1-2-3/   "
And so for, you'll need to follow 
the step that is show in the link.

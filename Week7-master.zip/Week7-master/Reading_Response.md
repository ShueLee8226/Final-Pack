Shue Lee
Matthew Harmon
CSCI 2461-71: Linux 

My response to the reading, “An Industry Guide to Becoming a Software Engineer” by Bill 
Langenberg. In this reading, it shows certain type of software skill you needed to have to become a 
software engineer, what employers are looking for, and how be productive with your work. Also, it 
some example questions that require certain type skills that is needed, and it show some example 
of code distributed environment. Furthermore, it shows some example of program language you 
might need as a software employee; such as, C++, Java, Python, Bash shell scripting, SQL. As 
far by reading this, it's helpful to know these thing for someone who want to become a software engineer, like the 
skills they need to have to become a software engineer and know what their employer expects they too have.

By far what Bill say in his slide, I think very helpful for someone who looking to be a software engineer 
employee because it shows what you need and the requirement of the basic to become a very successful software 
engineer. Known what you are doing and when to stop and ask for help, will likely help you keep your job.
Also, in his slide I like how he say, “The best performing engineers are able to balance asking teammates 
for answers to get unblocked quickly against spending time to figure out the answer themselves.”, I just really 
like how he say this line because I agree with him.When you are work you never wanted to waste time and 
the time is the essence to your work because everyone knows what’s going to happen when you are always
the last one to finish or spent the most time to your solving a problem without an explanation why. 
In addition, in his slide about “What Employers Look For” it is a very help as tip and guide to your dream 
job if you consider this as your long-term job

To me this is a very helpful reading because I will know what to do and the gist of what a 
software engineer job might look like. Being able to see what my future job and the skill that I 
needed is it very helpful to me because being able to have the skills that your employer is
looking for what make you stand out for other co-worker. As for this reading, I would 
recommend to other student who are interest into software engineer job because after reading this
it will make them understand what this job is looking for such as, the skills. After reading this 
slide from Bill Langenberg “An Industry Guide to Becoming a Software Engineer “, it helps me get a 
better understanding of this career path I’m taking, and it also change my perspective of the difference  
command in the Window and the Linux command. For this reading it also help me understand why taking this 
Linux class is important for me. Some of the material in the reading also relate to some the bash command in the Linux class to. 

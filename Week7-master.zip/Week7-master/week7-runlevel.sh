#!/bin/bash

clear
echo "Welcome to week 7 script"
echo "Let determines your current run level"
# by typing in runlevel
runlevel
sleep 2
echo "Another similar command that whill show your"
echo "current run level with the date and time"
echo "is using the command who"
# run the command who -r
who -r

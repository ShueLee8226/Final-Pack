## How we Deploy our project

```
1. check if apache2 is install
(if not do: sudo apt-get install apache2)

2.check apache2 server status by: sudo systemctl statue apache2 

3.go into the html file
(path: /var/www/html)

4.find the index.html and edit
(sudo nano index.html)

5.look for the <ul class ="nav navbar-var"> and under that line 
copy the (<li><a href="your team name.html">yourTeamName</a></li>)
and paste under the list of (<li><a hre="...) 

6.save and exit from the index.html

7.while in the html path create your team file with .html 
(name have to be the same what you put in the index.html)

8.Deploy complete, now just edited your team file.html and [ut what you want in there
```
[Link to help start html file](https://www.w3schools.com/html/default.asp)

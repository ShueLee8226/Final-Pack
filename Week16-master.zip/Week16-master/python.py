#hello
#This is how you create python file
#it's the same as shell script
#instead of echo it's print
#other then that every thing is the same just bit of change in some command

print"hello world"
test = "this is a variable"
print test

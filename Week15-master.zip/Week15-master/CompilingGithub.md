# Compiling a File in Github in your account in sootsplash

```
1.check git command
(if don't have git command do: git apt-get install git)

2.do: "git clone path name"
(example: git clone https://github.com/ShueLee8226/Week5.git)

3.after you done the cloning, edited the file

4.after your done editing the file, next push the repository out
do the following command:" git add * " press enter, the next
command is:" get commit -m "update" enter and your final command 
is "git push" and press enter and it should prompt you for your username and password.

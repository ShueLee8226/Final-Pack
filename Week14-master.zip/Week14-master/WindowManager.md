A window manager is service application that arrange window on screen to allow user to be able to interactive or
edited in the window screen. Window manager have many different kind, for example such as, mutter, gnome shell,
openbox, i3, and many more. Here is an example of how I change my window manager in ubuntu. First update you apt
by typing in “sudo apt-get update”. After the update type in this command type in “ sudo apt-get install unity-tweak-tool”.
After you install tweak tool open it the tweak tool program. From thereon you change your window manager, unity, appearance, 
the system. So for how change the window manage I think you just use the Teak tool to change the window manager?

To compile, first you’ll need to know what programming language you’re using such as, python , shell script, c++, java, etc ... 
For the compiler I will be using gedit something that similar to C++ programming language. First, check if you have gedit by type 
man gedit. To compiled a program or script type in “ gedit ” and the name of the file with “ .c ” at the end of the name.
It should prompt you a new screen and from there on type in the program. The first line should be something like this “ #include <stdio.h> ”
then enter to goto the next line. After the first line, type in “ main() { “ then click enter again so you will be in a new line 
and press tab to indent then type in printf(“”) then type in your string. With in the string you ended with \n then you’ll end your
string after you close the parentheses you put a semicolon.when you type in your string if should look something like this
“ printf(“type what you want here\n”); When you finish typing in your string close all your string string with } at the end of 
all your string and on a new line. When you’re done click save and close the program and go back to the terminal and type in
“gcc -o (name of the file) (name of the file with .c)” it show look something like this “gcc -o test test.c”. When to execute 
the program you just type in ./test just like how shell script is done. Also, you need to give permission to the file to run 
the program. To check the file to if you can run it type in “ls -l” it should show the list of the director or file in the path
your in. Look for your file name and look at the first column and see if it have  -rwxrwxr-x. If not run the command 
“chmod 777 (file name)” or type in “chmod +x (file name)”. After you type in those command it should give permission to the file 
you want to run. Now run the file again “./(file name)”. If you do not like type in the “./ “ every time you execute the programs,
you can change it. First, type in “gedit .(give it a name)” a gedit screen should appear you are going to type in if statement,
so first type in “if [ -n “$BASH_VERSION ]; then ”, go new line and then indent  then type in “ if [ -f $HOME/.bashrc” ]; then”,
new line again and indent, type in “ “$HOME/.bashrc” ”, new line, indent close your second if statement” by typing in “fi ”. After,
you close your second if statement go new line and close your first if statement, do the same thing, but no indent. The next step
is type a new if statement in the same gedit file you just created. In the gedit file, go to a new line and type in
“ if [ -d “$HOME/bin” ]; then ”, go to a new line and indent and type in PATH=”$HOME/bin:$PATH” ”, close the if statement. 
Goto another new line in type in “ export PATH=.:$PATH. Close the file that you are 
